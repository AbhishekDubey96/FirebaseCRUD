package com.example.demofirebase;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Model;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import org.w3c.dom.Text;

public class MyAdapter extends FirebaseRecyclerAdapter<Model,MyAdapter.myviewholder> {



    public MyAdapter(@NonNull FirebaseRecyclerOptions<Model> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, int position, @NonNull Model model) {
holder.Name.setText(model.getName());
holder.password.setText(model.getPassword());
holder.email.setText(model.getEmail());
holder.RatingStar.setText(model.getRatingStar());
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.singlerow,parent,false);
        return new myviewholder(view);

    }

    class myviewholder extends RecyclerView.ViewHolder{
TextView Name, email,RatingStar,password;
        public myviewholder(@NonNull View itemView) {
            super(itemView);
            Name=(TextView)itemView.findViewById(R.id.text1df);
            email=(TextView)itemView.findViewById(R.id.text2df);
            RatingStar=(TextView)itemView.findViewById(R.id.text3df);
            password=(TextView)itemView.findViewById(R.id.text4df);
        }
    }
}
